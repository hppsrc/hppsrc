$MASTER_PASSWORD = "1007983454"
# Variable global para habilitar/deshabilitar depuración
$script:DEBUG_FLAG = 1  # Cambiar a 1 para habilitar la depuración

    if ($script:DEBUG_FLAG -eq 1) {
        cls
    }

# Función de ayuda para mostrar mensajes de depuración
function Debug-Print {
    param(
        [string]$Message
    )

    if ($script:DEBUG_FLAG -eq 1) {
        Write-Host "[DEBUG] $Message" -ForegroundColor Yellow
    }
}

# Definicion de la funcion principal para la verificacion del codigo
function Vfy-Cd {
    # Establece enlace de parametros de cmdlet para practicas recomendadas
    [CmdletBinding()]
    param(
        # Parametro de entrada: el codigo a verificar (cadena de 10 digitos)
        [string]$c
    )

    # Bloque Try para manejo de errores generales inesperados
    try {
        # Define la ruta al archivo de configuracion del PC local
        # Este archivo debe contener el numero del PC (ej: "23")
        $f = "C:\Windows\windows_pc.cfg"

        # Define codigos de error y exito
        $e1 = "ERR_INV_LEN" # Error: Longitud Invalida
        $e2 = "ERR_NOT_INT" # Error: No es Entero/Numerico
        $e3 = "ERR_INV_PC_" # Error: PC no coincide
        $e4 = "ERR_COD_EXP" # Error: Codigo Expirado
        $e5 = "ERR_UNX_ERR" # Error: Inesperado (solo para catch final)
        $e6 = "ERR_CFG_FIL" # Error: Archivo configuración
        $e7 = "ERR_INV_SUM" # Error: Suma control inválida
        $e8 = "ERR_INV_TIM" # Error: Tiempo uso inválido
        $e9 = "ERR_INV_DIG" # Error: Dígitos impares inválidos
        $ok = "true"        # Exito: Codigo valido

		Debug-Print "ADM CHECK: Longitud del código: $($c.Length), Esperado: $($MASTER_PASSWORD.Length)"
        if ($c.Length -eq $MASTER_PASSWORD.Length) {

            # Verificar coincidencia
            if ($c -eq $MASTER_PASSWORD) {
                return $ok
            }

		}

        # CHK_1: Verifica si la longitud del codigo NO es 10
        Debug-Print "Longitud del código: $($c.Length), Esperado: 10"
        if ($c.Length -ne 10) {
            return "$e1; El codigo no es valido."
        }

        # CHK_2: Verifica si el codigo NO contiene solo digitos
        Debug-Print "Código contiene solo dígitos: $($c -match '^\d+$')"
        if ($c -notmatch '^\d+$') {
            return "$e2; El codigo no es valido."
        }

        # Define variable para almacenar el numero de PC leido del archivo
        $p = $null
        # Bloque Try especifico para la lectura del archivo de configuracion
        try {
            Debug-Print "Intentando leer archivo de PC: $f"
            # Lee el contenido del archivo (debe ser el numero del PC)
            $p = Get-Content $f -ErrorAction Stop
            # Intenta convertir el contenido leido a entero
            $p_int = [int]$p
            Debug-Print "Número de PC leído: $p_int"
        } catch {
            Debug-Print "Error leyendo archivo de PC: $_"
            # Si hay error leyendo o convirtiendo el numero del PC, retorna error de configuración
            return "$e6; Error con codigo de PC."
        }

# Extrae los digitos relevantes del codigo (basado en la logica de generacion PHP)
# $v1 (Primer digito impar aleatorio)
$d1 = [int]::Parse($c[0].ToString())  # Corregido
# $v2 y $v3 (Digitos del numero de PC)
$pc_c = [int]::Parse($c.Substring(1, 2))  # Corregido
# $v4 (Primer digito del minuto de generacion)
$m1 = [int]::Parse($c[3].ToString())  # Corregido
# $v5 (Digito de suma de control)
$suma = [int]::Parse($c[4].ToString())  # Corregido
# $v6 (Segundo digito del minuto de generacion)
$m2 = [int]::Parse($c[5].ToString())  # Corregido
# $v7, $v8, $v9 (Minutos totales de uso)
$mins = [int]::Parse($c.Substring(6, 3))  # Corregido
# $v10 (Ultimo digito impar aleatorio)
$d10 = [int]::Parse($c[9].ToString())  # Corregido

        Debug-Print @"
Valores extraídos:
- Primer dígito (d1): $d1
- PC código (pc_c): $pc_c
- Minuto primer dígito (m1): $m1
- Suma control (suma): $suma
- Minuto segundo dígito (m2): $m2
- Minutos totales (mins): $mins
- Último dígito (d10): $d10
"@

		Debug-Print "CHK_3: Verifica si el número de PC es correcto"
		if ($p_int -ne $pc_c ) {
			Debug-Print "Número de PC inválido: $p_int"
			return "$e6; Error con codigo de PC."
		}

        # Ajuste para usar la zona horaria de Colombia (America/Bogota)
        try {
            Debug-Print "Intentando obtener zona horaria Colombia"
            $zonaColombiana = [System.TimeZoneInfo]::FindSystemTimeZoneById("SA Pacific Standard Time") # Zona horaria de Colombia
            $tiempo_actual = [System.TimeZoneInfo]::ConvertTime((Get-Date), $zonaColombiana)
            Debug-Print "Hora actual (Colombia): $tiempo_actual"
        } catch {
            Debug-Print "Error zona horaria: $_. Usando hora local"
            # Si no se puede obtener la zona horaria correcta, usa la hora local pero advierte
            $tiempo_actual = Get-Date
            Write-Warning "No se pudo usar la zona horaria de Colombia. Usando hora local."
        }

        # CHK_4: Verifica la suma de control (HABILITADO Y ACTUALIZADO)
        $mes_actual = [int]::Parse($tiempo_actual.ToString('MM')) # Obtiene el mes como numero (1-12)
        $dia_actual = [int]::Parse($tiempo_actual.ToString('dd')) # Obtiene el dia como numero (1-31)
		# numero de semana del año (1-53) usando -UFormat %V
		$semana_actual = Get-Date -UFormat %V # Obtiene la semana como numero (1-53)
		# $semana_actual = [int]::Parse($tiempo_actual.ToString('ww')) # Obtiene la semana como numero (1-53)

        # Calcula la suma de control esperada con la nueva formula: ultimo digito de la suma
        $suma_total = $mes_actual + $dia_actual + $semana_actual
        # Convierte la suma a string y toma el ultimo caracter, luego lo convierte a int
        $suma_esperada = [int]::Parse($suma_total.ToString()[-1])

        Debug-Print @"
Suma de control:
- Mes actual: $mes_actual
- Día actual: $dia_actual
- Semana actual: $semana_actual
- Suma total: $suma_total
- Suma esperada: $suma_esperada
- Suma en código: $suma
"@

        if ($suma -ne $suma_esperada) {
            return "$e7; El codigo no es valido."
        }

        # CHK_5: Verifica que los minutos totales extraidos sean uno de los valores validos de uso
        $mv = @(15, 30, 45, 60, 90, 120) # Tiempos de uso validos en minutos
        if ($mins -notin $mv) {
            return "$e8; El codigo no es valido."
        }

        # CHK_6: Verifica si el primer O el ultimo digito NO son impares
        if (($d1 % 2 -eq 0) -or ($d10 % 2 -eq 0)) {
            return "$e9; El codigo no es valido."
        }

        # CHK_7: Compara el numero de PC extraido del codigo con el leido del archivo local
        if ($pc_c -ne $p_int) {
            return "$e3; El codigo no es valido en este PC." # Numero de PC no coincide
        }

        # Calcula el minuto de generacion combinando los digitos $v4 y $v6
        $mg = ($m1 * 10) + $m2

        # Obtiene el minuto actual (de la zona horaria correcta)
        $ma = $tiempo_actual.Minute

        # Para debug, mostrar la hora usada
        Debug-Print "Hora usada para validación: $tiempo_actual (Minuto: $ma)"
        Debug-Print "Minuto extraído del código: $mg"

        # CHK_8: Verifica si el codigo ha expirado.
        # El codigo se considera expirado si han pasado mas de 10 minutos desde el minuto en que fue generado.
        # Maneja el cruce de hora (ej: generado a XX:55, ahora (XX+1):05)
        $df = 0
        if ($mg -gt $ma) {
            # El minuto de generacion es mayor que el actual, implica cruce de hora
            $df = ($ma + 60) - $mg
        } else {
            # El minuto de generacion es menor o igual al actual
            $df = $ma - $mg
        }

        Debug-Print "Diferencia de minutos: $df"

        # Considera expirado si la diferencia es mayor a 10 minutos o si la diferencia es negativa (codigo del futuro?)
        # La comprobacion $df -gt 50 es una salvaguarda para evitar falsos positivos en diferencias negativas grandes
        if ($df -gt 10 -or ($df -lt 0 -and $df -gt -50)) {
             return "$e4; El codigo ha expirado." # Codigo expirado o invalido por tiempo (mas de 10 minutos)
        }

        # Si todas las verificaciones anteriores fueron superadas, retorna exito
        return $ok

    } catch {
        # Bloque Catch general para cualquier otro error no manejado especificamente
        # Retorna codigo de error inesperado
        Debug-Print "Error general: $_"
        return "$e5; Error inesperado."
    }
}

# --- Ejemplo de como llamar la funcion ---
# Reemplaza "1234567890" con el codigo que quieres verificar
# Asegurate de que el archivo C:\Windows\windows_pc.cfg exista y contenga el numero del PC correcto.
<#
$script:DEBUG_FLAG = 1  # Habilitar depuración
$codigo_a_probar = "1234567890"
$resultado = Vfy-Cd -c $codigo_a_probar
Write-Host "Resultado: $resultado"
#>