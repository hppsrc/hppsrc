$BUILD_CONTROL = "BUILD 2505091601"

New-Item ($env:temp + "\validator_check_false.txt")
remove-item ($env:temp + "\validator_check_true.txt")
cls

# Asegurar que los ensamblados esten cargados al inicio
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# --- Diagnostico: Verificar si los tipos de Windows Forms estan disponibles ---
try {
    # Intentar crear una instancia simple para forzar la carga de tipos si es necesario
    $dummyForm = New-Object System.Windows.Forms.Form
    $dummyForm.Dispose()
    [void][System.Windows.Forms.StartPosition]
    Write-Host "DEBUG: Tipos de Windows Forms verificados con exito."
} catch {
    Write-Error "DEBUG: ERROR: No se pudieron verificar los tipos de Windows Forms. Esto podria causar problemas. Error: $($_.Exception.Message)"
}
# --- Fin Diagnostico ---


# Variable para controlar si el cierre es por el boton
$closingByButton = $false
# Variable para almacenar el proceso del ejecutable externo (mantenemos por referencia inicial)
$externalProcess = $null
# Variable para almacenar el ID del proceso iniciado (mantenemos por referencia inicial)
$externalProcessId = $null
# Variable para indicar si el validador se cargo correctamente
$validatorLoaded = $false
# Ruta del archivo de señal para validacion exitosa
$validationSuccessFile = Join-Path $env:TEMP "validator_check_true.txt"


# Obtener el directorio del script actual una sola vez al inicio
# Usamos $PSScriptRoot si esta disponible (PS 3.0+), sino Split-Path
$scriptDir = if ($PSScriptRoot) { $PSScriptRoot } else { Split-Path -Parent $MyInvocation.MyCommand.Definition }
$exePath = Join-Path $scriptDir "keyhook_locker.exe"
$qrImagePath = Join-Path $scriptDir "QR.png"
# Ruta al archivo validator.ps1
$validatorPath = Join-Path $scriptDir "validator.ps1"


# --- Cargar el script del validador ---
Write-Host "DEBUG: Intentando cargar script validador desde: $validatorPath"
if (Test-Path $validatorPath) {
    try {
        # Source el script para que sus funciones esten disponibles
        # Usamos un punto (.) para sourcear en el ambito actual
        . $validatorPath
        Write-Host "DEBUG: Script validador cargado con exito."

        # --- Diagnostico: Verificar si la funcion Vfy-Cd esta disponible ---
        # Usamos Get-Command en el ambito actual
        if (Get-Command -Name Vfy-Cd -ErrorAction SilentlyContinue -Scope Local) {
            Write-Host "DEBUG: Funcion Vfy-Cd encontrada en el ambito local despues de cargar el validador."
            $validatorLoaded = $true # Marcar como cargado solo si la funcion se encuentra
        } elseif (Get-Command -Name Vfy-Cd -ErrorAction SilentlyContinue -Scope Global) {
             Write-Host "DEBUG: Funcion Vfy-Cd encontrada en el ambito global despues de cargar el validador."
             $validatorLoaded = $true # Marcar como cargado si se encuentra globalmente
        }
        else {
            Write-Error "DEBUG: ERROR: La funcion Vfy-Cd NO se encontro en ningun ambito despues de cargar el script '$validatorPath'. La validacion no funcionara."
            $validatorLoaded = $false
        }
        # --- Fin Diagnostico ---

    } catch {
        Write-Error "DEBUG: ERROR al cargar el script validador '$validatorPath'. Asegurate de que existe y no tiene errores de sintaxis. Error: $($_.Exception.Message)"
        $validatorLoaded = $false
    }
} else {
    Write-Error "DEBUG: El script validador '$validatorPath' no se encontro."
    $validatorLoaded = $false
}


# Create form
$form = New-Object System.Windows.Forms.Form
$form.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::None
# La linea 44 del error original - Intentando establecer StartPosition despues de verificar tipos
$form.StartPosition = [System.Windows.Forms.StartPosition]::Manual
$form.BackColor = [System.Drawing.ColorTranslator]::FromHtml("#4477d1")
$form.TopMost = $true
# Evitar que la ventana aparezca en la barra de tareas
$form.ShowInTaskbar = $false

# Get screen dimensions
$screen = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds

# Restablecer tamaño y posicion a pantalla completa (extra 10px en cada lado)
$form.Width = $screen.Width + 20
$form.Height = $screen.Height + 20
$form.Location = New-Object System.Drawing.Point(-10, -10)


# Create Cerrar button (positioned later)
$buttonCerrar = New-Object System.Windows.Forms.Button
$buttonCerrar.Text = "Cerrar"
$buttonCerrar.Width = 100
$buttonCerrar.Height = 30
$buttonCerrar.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
$buttonCerrar.BackColor = [System.Drawing.Color]::White
$buttonCerrar.ForeColor = [System.Drawing.ColorTranslator]::FromHtml("#007ACC")

# Create PictureBox for the QR image
$pictureBoxQR = New-Object System.Windows.Forms.PictureBox
# Establecer un tamaño fijo para el PictureBox
$pictureBoxQR.Width = 200
$pictureBoxQR.Height = 200
# Set the size mode to stretch the image to fit the PictureBox
$pictureBoxQR.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::StretchImage
# Set a default background color in case the image doesn't load
$pictureBoxQR.BackColor = [System.Drawing.Color]::Transparent


# Load the image into the PictureBox
try {
    # Usar FromFile para cargar la imagen directamente
    if (Test-Path $qrImagePath) {
        $pictureBoxQR.Image = [System.Drawing.Image]::FromFile($qrImagePath)
        Write-Host "DEBUG: Imagen QR cargada desde: $qrImagePath"
    } else {
        Write-Warning "DEBUG: La imagen QR no se encontro en '$qrImagePath'."
        $pictureBoxQR.Visible = $false
    }
} catch {
    Write-Warning "DEBUG: No se pudo cargar la imagen QR desde '$qrImagePath'. Asegurate de que es un formato de imagen valido. Error: $($_.Exception.Message)"
    # Optionally, hide the PictureBox if the image doesn't load
    $pictureBoxQR.Visible = $false
}

# --- Controles: Input, Labels y Botones ---
$textBoxInput = New-Object System.Windows.Forms.TextBox
$textBoxInput.Width = 350 # Ancho mas grande como en la imagen
$textBoxInput.Height = 30 # Altura estandar, puede ajustarse si es necesario
$textBoxInput.PlaceholderText = "Ingrese su código" # Texto de ejemplo actualizado con ortografia correcta
$textBoxInput.Font = New-Object System.Drawing.Font("Arial", 12) # Fuente un poco mas grande para el input

$labelStatus = New-Object System.Windows.Forms.Label
$labelStatus.AutoSize = $true # Ajustar tamaño de la etiqueta al texto
$labelStatus.Text = "status" # Texto inicial de la etiqueta
$labelStatus.ForeColor = [System.Drawing.Color]::White # Color del texto (lo mantenemos blanco para visibilidad)
$labelStatus.BackColor = [System.Drawing.Color]::Transparent # Fondo inicial transparente
$labelStatus.Font = New-Object System.Drawing.Font("Arial", 10) # Fuente mas pequeña que el input, pero mas grande que antes

# Create Limpiar button
$buttonLimpiar = New-Object System.Windows.Forms.Button
$buttonLimpiar.Text = "Limpiar"
$buttonLimpiar.Width = 80 # Ancho del boton Limpiar
$buttonLimpiar.Height = 30 # Altura igual que el input
$buttonLimpiar.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
$buttonLimpiar.BackColor = [System.Drawing.Color]::White
$buttonLimpiar.ForeColor = [System.Drawing.ColorTranslator]::FromHtml("#007ACC")

# Add click event for Limpiar button
$buttonLimpiar.Add_Click({
    $textBoxInput.Text = "" # Limpiar el texto del input
    Write-Host "DEBUG: Boton 'Limpiar' clickeado. Campo de texto limpiado."
    # Opcional: Resetear el color de fondo del status al limpiar
    $labelStatus.BackColor = [System.Drawing.Color]::Transparent
    $labelStatus.Text = "status"
    $labelStatus.ForeColor = [System.Drawing.Color]::White
})

# --- Nueva etiqueta sobre el QR ---
$labelQRHeader = New-Object System.Windows.Forms.Label
$labelQRHeader.AutoSize = $true # Ajustar tamaño de la etiqueta al texto
$labelQRHeader.Text = "escanea para desbloquear" # Texto de la nueva etiqueta
$labelQRHeader.ForeColor = [System.Drawing.Color]::White # Color del texto
$labelQRHeader.Font = New-Object System.Drawing.Font("Arial", 12, [System.Drawing.FontStyle]::Bold) # Fuente y estilo mas grande

# --- Nuevo boton Verificar Código ---
$buttonVerificar = New-Object System.Windows.Forms.Button
$buttonVerificar.Text = "Verificar código" # Texto del boton con ortografia correcta
$buttonVerificar.Width = 120 # Ancho del boton Verificar
$buttonVerificar.Height = 30 # Altura igual que el input
$buttonVerificar.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
$buttonVerificar.BackColor = [System.Drawing.Color]::White
$buttonVerificar.ForeColor = [System.Drawing.ColorTranslator]::FromHtml("#007ACC")

# Deshabilitar el boton Verificar si el validador no se cargo
if (-not $validatorLoaded) {
    $buttonVerificar.Enabled = $false
    Write-Warning "DEBUG: Boton 'Verificar código' deshabilitado porque el validador no se cargo correctamente."
}


# Add click event for Verificar button
$buttonVerificar.Add_Click({
    $codigoIngresado = $textBoxInput.Text
    Write-Host "DEBUG: Boton 'Verificar código' clickeado. Código ingresado: '$codigoIngresado'"

    # --- Logica para llamar al validador y actualizar el estado ---
    # La verificacion $validatorLoaded ya se hizo al habilitar/deshabilitar el boton
    if ($validatorLoaded) { # Solo intentar si el validador se cargo
        try {
            # Llamar a la funcion Vfy-Cd del script validador
            # Pasamos el codigo ingresado como string, ya que la funcion espera [string]$c
            # La conversion a Int si es necesaria debe ser manejada dentro de Vfy-Cd
            $validationResult = Vfy-Cd -c $codigoIngresado
            Write-Host "DEBUG: Resultado del validador: '$validationResult'"

            # Actualizar la etiqueta de estado
            $labelStatus.Text = "Estado: $validationResult"

            # Cambiar el COLOR DE FONDO de la etiqueta segun el resultado
            if ($validationResult -eq "true") {
                $labelStatus.BackColor = [System.Drawing.Color]::LightGreen # Fondo verde para exito
                $labelStatus.ForeColor = [System.Drawing.Color]::Black # Texto negro para visibilidad
                Write-Host "DEBUG: Codigo valido. Fondo de etiqueta de estado en verde."

                # --- Logica para crear archivo de señal y cerrar el formulario ---
                Write-Host "DEBUG: Codigo valido. Creando archivo de validacion exitosa: $validationSuccessFile"
                try {
                    New-Item -Path $validationSuccessFile -ItemType File -Force | Out-Null
                    Write-Host "DEBUG: Archivo de validacion exitosa creado con exito."
                } catch {
                    Write-Error "DEBUG: ERROR al crear archivo de validacion exitosa '$validationSuccessFile'. Error: $($_.Exception.Message)"
                }

                # Actuar como si se hubiera hecho clic en el boton Cerrar
                $closingByButton = $true
                # Detener los temporizadores antes de cerrar el formulario
                $formActivateTimer.Stop()
                $processCheckTimer.Stop()
                Write-Host "DEBUG: Cerrando formulario debido a validacion exitosa."
                
                new-item ($env:temp + "\validator_check_true.txt")
                remove-item ($env:temp + "\validator_check_false.txt")
                
                $form.Close() # Cerrar el formulario
                # --- Fin Logica de cierre ---

            } else {
                $labelStatus.BackColor = [System.Drawing.Color]::Red # Fondo rojo para cualquier error
                $labelStatus.ForeColor = [System.Drawing.Color]::White # Texto blanco para visibilidad
                Write-Host "DEBUG: Codigo invalido. Fondo de etiqueta de estado en rojo."
            }

        } catch {
            Write-Error "DEBUG: ERROR al llamar a la funcion Vfy-Cd. Error: $($_.Exception.Message)"
            $labelStatus.Text = "Error de validación"
            $labelStatus.BackColor = [System.Drawing.Color]::OrangeRed # Fondo naranja/rojo para errores internos
            $labelStatus.ForeColor = [System.Drawing.Color]::White
        }
    } else {
        Write-Warning "DEBUG: El script validador o la funcion Vfy-Cd no estan disponibles (dentro del click)."
        $labelStatus.Text = "Validador no disponible"
        $labelStatus.BackColor = [System.Drawing.Color]::OrangeRed
        $labelStatus.ForeColor = [System.Drawing.Color]::White
    }
    # --- Fin Logica de validacion ---
})

# --- Nueva etiqueta debajo del QR ---
$labelBuildInfo = New-Object System.Windows.Forms.Label
$labelBuildInfo.AutoSize = $true # Ajustar tamaño de la etiqueta al texto
$labelBuildInfo.Text = $BUILD_CONTROL # Texto de la etiqueta de build
$labelBuildInfo.ForeColor = [System.Drawing.Color]::White # Color del texto
$labelBuildInfo.Font = New-Object System.Drawing.Font("Arial", 8) # Fuente pequeña

# Create a Timer to periodically activate the form
$formActivateTimer = New-Object System.Windows.Forms.Timer
$formActivateTimer.Interval = 500 # 0.5 seconds
$formActivateTimer.Add_Tick({
    # Activate the form to bring it to the front and give it focus
    $form.Activate()
})

# --- Timer para verificar y reiniciar el proceso externo ---
$processCheckTimer = New-Object System.Windows.Forms.Timer
$processCheckTimer.Interval = 500 # 0.5 seconds
$processCheckTimer.Add_Tick({
    Write-Host "DEBUG: processCheckTimer Tick. Verificando estado del hook..."

    $isProcessRunning = $false

    # Usar Get-Process para verificar si alguna instancia del ejecutable esta corriendo por nombre
    # -ErrorAction SilentlyContinue evita que muestre error si no encuentra el proceso
    $runningProcessesByName = Get-Process -ProcessName "keyhook_locker" -ErrorAction SilentlyContinue

    if ($runningProcessesByName -ne $null -and $runningProcessesByName.Count -gt 0) {
        Write-Host "DEBUG: Se encontraron $($runningProcessesByName.Count) instancia(s) de 'keyhook_locker.exe' por nombre."
        $isProcessRunning = $true
        # Opcional: Si quieres actualizar la referencia al objeto proceso (aunque no esencial para la terminacion por nombre)
        # $externalProcess = $runningProcessesByName[0]
        # $externalProcessId = $runningProcessesByName[0].Id
    } else {
        Write-Host "DEBUG: No se encontraron instancias de 'keyhook_locker.exe' por nombre."
        $isProcessRunning = $false
    }


    # Si ningun proceso esta corriendo, intentar iniciar/reiniciar
    if (-not $isProcessRunning) {
        Write-Warning "DEBUG: Ninguna instancia de 'keyhook_locker.exe' encontrada. Intentando iniciar/reiniciar..."

        # Reutilizar $exePath calculado al inicio
        try {
            # Intentar iniciar/reiniciar el proceso
            # -PassThru para obtener el objeto proceso
            # -ErrorAction Stop para que lance una excepcion si falla
            $newProcess = Start-Process -FilePath $exePath -PassThru -ErrorAction Stop
            # Actualizar la variable externalProcess y su ID SOLO si Start-Process fue exitoso
            # Esto es util para la logica de terminacion si queremos usar el ID,
            # pero la terminacion por nombre es mas robusta aqui.
            $externalProcess = $newProcess
            $externalProcessId = $newProcess.Id
            Write-Host "DEBUG: Proceso iniciado/reiniciado con exito con ID: $($externalProcess.Id)"
            # Si se reinicia con exito, no hacemos nada mas en este Tick

        } catch {
            Write-Error "DEBUG: ERROR al iniciar/reiniciar el ejecutable '$exePath'. Cerrando formulario. Error: $($_.Exception.Message)"
            # Si el reinicio falla, detener y liberar este temporizador
            $processCheckTimer.Stop()
            $processCheckTimer.Dispose()

            # Si el formulario aun no se ha cerrado, cerrarlo porque no se pudo reiniciar el hook
            if (-not $form.IsDisposed -and $form.Visible) {
                 # Indicar que no es un cierre por el boton para evitar el FormClosing cancel
                $closingByButton = $false
                $form.Close()
            }
        }
    } else {
        Write-Host "DEBUG: Se detecto que el proceso hook esta corriendo. No se requiere iniciar/reiniciar."
    }
})
# --- Fin Timer de verificacion y reinicio ---

# --- Timer para el limite de tiempo (eliminado) ---
# $timeLimitTimer = New-Object System.Windows.Forms.Timer
# $timeLimitTimer.Interval = 10000 # 10 segundos
# $timeLimitTimer.Tick.Add({
#     Write-Host "DEBUG: timeLimitTimer Tick. Tiempo limite alcanzado."
#     # Detener este temporizador para que no se repita
#     $timeLimitTimer.Stop()
#     $timeLimitTimer.Dispose() # Liberar recursos del temporizador

#     # Mostrar MessageBox de fin de tiempo
#     [System.Windows.Forms.MessageBox]::Show("¡FIN DEL TIEMPO!", "Tiempo Agotado", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Warning)
#     Write-Host "DEBUG: MessageBox mostrado: FIN DEL TIEMPO."

#     # Opcional: Cerrar el formulario principal automaticamente despues del mensaje
#     # $form.Close()
# })
# --- Fin Timer (eliminado) ---


# Position controls - needs to be done after form is shown
$form.Add_Shown({
    param($sender, $e)
    $form.Activate()
    $form.Focus()

    # --- Posicionamiento ---
    $padding = 50 # Espacio desde el borde superior e izquierdo
    $spacing = 20 # Espacio entre elementos

    # Posicionar la etiqueta sobre el QR code
    # Alinear horizontalmente con el centro del PictureBox
    # Asegurarse de que la etiqueta no se salga por arriba
    $qrHeaderY = [int]($padding - $labelQRHeader.Height - 5)
    if ($qrHeaderY -lt 0) { $qrHeaderY = 5 } # Pequeño margen si se sale
    $labelQRHeader.Location = New-Object System.Drawing.Point([int]($padding + ($pictureBoxQR.Width - $labelQRHeader.Width) / 2), $qrHeaderY) # 5px de espacio vertical sobre el QR

    # Posicionar la imagen QR cerca de la esquina superior izquierda
    if ($pictureBoxQR.Visible) {
        $pictureBoxQR.Location = New-Object System.Drawing.Point([int]$padding, [int]$padding)

        # Posicionar la etiqueta de Build justo debajo del QR
        $labelBuildInfo.Location = New-Object System.Drawing.Point([int]($padding + ($pictureBoxQR.Width - $labelBuildInfo.Width) / 2), [int]($padding + $pictureBoxQR.Height + 5)) # 5px de espacio vertical debajo del QR

        # Posicionar el campo de texto a la derecha de la imagen QR
        $textBoxInput.Location = New-Object System.Drawing.Point([int]($padding + $pictureBoxQR.Width + $spacing), [int]$padding)

        # Posicionar el boton Limpiar a la derecha del campo de texto
        $buttonLimpiar.Location = New-Object System.Drawing.Point([int]($textBoxInput.Location.X + $textBoxInput.Width + $spacing), [int]$padding) # Alinear verticalmente con el input

        # Posicionar el boton Verificar a la derecha del boton Limpiar
        $buttonVerificar.Location = New-Object System.Drawing.Point([int]($buttonLimpiar.Location.X + $buttonLimpiar.Width + $spacing), [int]$padding) # Alinear verticalmente con el input

        # Posicionar la etiqueta debajo del campo de texto, alineada a la izquierda con el campo de texto
        $labelStatus.Location = New-Object System.Drawing.Point([int]($textBoxInput.Location.X), [int]($textBoxInput.Location.Y + $textBoxInput.Height + 5)) # 5px de espacio vertical

    } else {
        # Si la imagen QR no es visible, posicionar los controles desde la esquina superior izquierda
        # Posicionar la etiqueta sobre donde estaria el QR
         $qrHeaderY = [int]($padding - $labelQRHeader.Height - 5)
         if ($qrHeaderY -lt 0) { $qrHeaderY = 5 }
         $labelQRHeader.Location = New-Object System.Drawing.Point([int]$padding, $qrHeaderY)

         # Posicionar la etiqueta de Build debajo de donde estaria el QR
         $labelBuildInfo.Location = New-Object System.Drawing.Point([int]($padding + ($pictureBoxQR.Width - $labelBuildInfo.Width) / 2), [int]($padding + $pictureBoxQR.Height + 5))


        $textBoxInput.Location = New-Object System.Drawing.Point([int]$padding, [int]$padding)
        $buttonLimpiar.Location = New-Object System.Drawing.Point([int]($textBoxInput.Location.X + $textBoxInput.Width + $spacing), [int]$padding)
        $buttonVerificar.Location = New-Object System.Drawing.Point([int]($buttonLimpiar.Location.X + $buttonLimpiar.Width + $spacing), [int]$padding)
        $labelStatus.Location = New-Object System.Drawing.Point([int]$textBoxInput.Location.X, [int]($textBoxInput.Location.Y + $textBoxInput.Height + 5))
    }

    # Posicionar el boton Cerrar en la esquina inferior derecha
    $buttonCerrar.Location = New-Object System.Drawing.Point([int]($form.Width - $buttonCerrar.Width - $padding), [int]($form.Height - $buttonCerrar.Height - $padding))


    # Start the form activation timer after the form is shown
    $formActivateTimer.Start()
    # El processCheckTimer se inicia despues de iniciar el proceso externo inicialmente
    # El timeLimitTimer se ha eliminado
})

# Add button click event for Cerrar button
$buttonCerrar.Add_Click({
    # Indicar que el cierre es por el boton
    $closingByButton = $true
    # Stop the timers before closing the form
    $formActivateTimer.Stop()
    $processCheckTimer.Stop()
    # El timeLimitTimer se ha eliminado
    Write-Host "DEBUG: Boton 'Cerrar' clickeado. Deteniendo timers."
    $form.Close()
})

# Handle FormClosing event to prevent closure by other means (like Alt+F4)
$form.Add_FormClosing({
    param($sender, $e)
    Write-Host "DEBUG: Evento FormClosing iniciado. closingByButton es: $closingByButton"
    # Si el cierre no fue iniciado por el boton, cancelar el cierre
    if (-not $closingByButton) {
        $e.Cancel = $true
        Write-Host "DEBUG: Cierre cancelado (no fue por boton)."
    } else {
        # If closing by button, dispose the timers and picture box image
        Write-Host "DEBUG: Cierre permitido (fue por boton). Disposing resources."
        if ($formActivateTimer -ne $null) { $formActivateTimer.Dispose() }
        if ($processCheckTimer -ne $null) { $processCheckTimer.Dispose() }
        # El timeLimitTimer se ha eliminado
        # if ($timeLimitTimer -ne $null -and -not $timeLimitTimer.Disposed) { $timeLimitTimer.Dispose() } # Disponer el temporizador de limite de tiempo

        # --- Logica para terminar TODAS las instancias del ejecutable externo al cerrar el formulario ---
        Write-Host "DEBUG: Intentando terminar TODAS las instancias de 'keyhook_locker.exe' al cerrar el formulario..."
        try {
            # Usar Get-Process para encontrar todas las instancias por nombre
            $processesToTerminate = Get-Process -ProcessName "keyhook_locker" -ErrorAction SilentlyContinue

            if ($processesToTerminate -ne $null -and $processesToTerminate.Count -gt 0) {
                Write-Host "DEBUG: Encontradas $($processesToTerminate.Count) instancia(s) para terminar."
                # Iterar y terminar cada instancia encontrada
                $processesToTerminate | ForEach-Object {
                    Write-Host "DEBUG: Terminando instancia con ID: $($_.Id)..."
                    Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue
                    Write-Host "DEBUG: Instancia con ID: $($_.Id) terminada (o ya no estaba corriendo)."
                }
            } else {
                Write-Host "DEBUG: No se encontraron instancias de 'keyhook_locker.exe' para terminar."
            }
        } catch {
            Write-Warning "DEBUG: WARNING: Ocurrio un error al intentar terminar procesos por nombre. Error: $($_.Exception.Message)"
        }
        # --- Fin Logica para terminar TODAS las instancias ---

        if ($pictureBoxQR.Image -ne $null) {
            $pictureBoxQR.Image.Dispose()
        }
        if ($pictureBoxQR -ne $null) {
            $pictureBoxQR.Dispose()
        }
         if ($labelQRHeader -ne $null) {
            $labelQRHeader.Dispose()
        }
         if ($textBoxInput -ne $null) {
            $textBoxInput.Dispose()
        }
         if ($labelStatus -ne $null) {
            $labelStatus.Dispose()
        }
         if ($buttonLimpiar -ne $null) {
            $buttonLimpiar.Dispose()
        }
         if ($buttonCerrar -ne $null) {
            $buttonCerrar.Dispose()
        }
         if ($buttonVerificar -ne $null) {
            $buttonVerificar.Dispose()
        }
         if ($labelBuildInfo -ne $null) {
            $labelBuildInfo.Dispose()
        }
    }
})

# Add ALL controls to form controls
$form.Controls.Add($pictureBoxQR)
# $form.Controls.Add($buttonCerrar) # Añadir el boton Cerrar
$form.Controls.Add($textBoxInput) # Añadir el campo de texto
$form.Controls.Add($labelStatus) # Añadir la etiqueta
$form.Controls.Add($buttonLimpiar) # Añadir el boton Limpiar
$form.Controls.Add($labelQRHeader) # Añadir la nueva etiqueta sobre el QR
$form.Controls.Add($buttonVerificar) # Añadir el boton Verificar
$form.Controls.Add($labelBuildInfo) # Añadir la etiqueta de build


# --- Logica para iniciar el ejecutable externo inicialmente ---

Write-Host "DEBUG: Intentando iniciar hook inicialmente: $exePath"

try {
    # Iniciar el proceso externo y guardar su objeto y ID
    # -PassThru para obtener el objeto proceso
    # -ErrorAction Stop para que lance una excepcion si falla
    $newProcess = Start-Process -FilePath $exePath -PassThru -ErrorAction Stop
    $externalProcess = $newProcess
    $externalProcessId = $newProcess.Id # Almacenar el ID del proceso iniciado
    Write-Host "DEBUG: Proceso hook iniciado con ID: $($externalProcess.Id)"
    # Iniciar el temporizador de verificacion del proceso despues de iniciarlo con exito
    $processCheckTimer.Start()
    Write-Host "DEBUG: processCheckTimer iniciado."

} catch {
    Write-Error "DEBUG: ERROR al iniciar el ejecutable '$exePath' inicialmente. Asegurate de que existe en el mismo directorio que el script. Error: $($_.Exception.Message)"
    # Si no se pudo iniciar el ejecutable, cerrar el formulario
    $form.Close()
    # Salir del script si no se pudo iniciar el ejecutable
    exit
}

# --- Mostrar el formulario (esto bloquea el script hasta que se cierra el formulario) ---
Write-Host "DEBUG: Mostrando formulario. Script bloqueado hasta que se cierra."
$form.ShowDialog()

# --- Logica para terminar el ejecutable externo cuando el script finaliza despues de ShowDialog ---
# Esta seccion es una red de seguridad si el FormClosing no se ejecuta por alguna razon.
# La logica principal de terminacion esta ahora en FormClosing.

Write-Host "DEBUG: Script finalizando despues de ShowDialog. Verificando si el hook necesita terminarse (red de seguridad)."

# Intentar terminar CUALQUIER instancia restante con el mismo nombre como red de seguridad
Write-Host "DEBUG: Intentando terminar cualquier otra instancia restante de 'keyhook_locker' desde el final del script (red de seguridad)."
try {
    $processesToTerminate = Get-Process -ProcessName "keyhook_locker" -ErrorAction SilentlyContinue
     if ($processesToTerminate -ne $null -and $processesToTerminate.Count -gt 0) {
        Write-Host "DEBUG: Encontradas $($processesToTerminate.Count) instancia(s) para terminar."
        $processesToTerminate | ForEach-Object {
            Write-Host "DEBUG: Terminando instancia con ID: $($_.Id) desde red de seguridad."
            Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue
            Write-Host "DEBUG: Instancia con ID: $($_.Id) terminada (o ya no estaba corriendo)."
        }
    } else {
        Write-Host "DEBUG: No se encontraron instancias de 'keyhook_locker.exe' para terminar en red de seguridad."
    }
} catch {
    Write-Warning "DEBUG: WARNING: Ocurrio un error al intentar terminar procesos por nombre en red de seguridad. Error: $($_.Exception.Exception.Message)"
}


# Disponer los temporizadores y el picture box si ShowDialog somehow exits without the FormClosing event
# (menos comun pero buena practica)
# Ya se llama en FormClosing, pero lo dejamos aqui por si acaso
Write-Host "DEBUG: Disposing timers and picture box if not already disposed."
if ($formActivateTimer -ne $null -and -not $formActivateTimer.Disposed) { $formActivateTimer.Dispose() }
if ($processCheckTimer -ne $null -and -not $processCheckTimer.Disposed) { $processCheckTimer.Dispose() }
# if ($timeLimitTimer -ne $null -and -not $timeLimitTimer.Disposed) { $timeLimitTimer.Dispose() } # Disponer el temporizador de limite de tiempo
if ($pictureBoxQR.Image -ne $null) {
    $pictureBoxQR.Image.Dispose()
}
if ($pictureBoxQR -ne $null -and -not $pictureBoxQR.IsDisposed) {
    $pictureBoxQR.Dispose()
}
if ($labelQRHeader -ne $null) {
    $labelQRHeader.Dispose()
}
if ($textBoxInput -ne $null) {
    $textBoxInput.Dispose()
}
if ($labelStatus -ne $null) {
    $labelStatus.Dispose()
}
if ($buttonLimpiar -ne $null) {
    $buttonLimpiar.Dispose()
}
if ($buttonCerrar -ne $null) {
    $buttonCerrar.Dispose()
}
if ($buttonVerificar -ne $null) {
    $buttonVerificar.Dispose()
}
if ($labelBuildInfo -ne $null) {
    $labelBuildInfo.Dispose()
}
Write-Host "DEBUG: Script finalizado."
exit
