@echo off

echo Ejecute este script como administrador para que todo funcione correctamente.
timeout /t 5 

if NOT EXIST "%~p0data_admin.zip" (
  echo NO SE ENCONTRO LOS DATOS DEL PROGRAMA.
  pause
  exit
)

cd %~p0

powershell "Expand-Archive -Path data_admin.zip -DestinationPath C:\Windows\UDCPCAdmin -Force"

powershell -Command "$mp=$null; while(-not [int]::TryParse((Read-Host 'Ingrese una clave maestra (solo numeros)'), [ref]$mp)){Write-Host 'Error: Debe ser un numero' -ForegroundColor Red}; if(Test-Path \"$env:systemroot\UDCPCAdmin\validator.ps1\"){$content=Get-Content \"$env:systemroot\UDCPCAdmin\validator.ps1\"; if($content -match '^\$MASTER_PASSWORD'){$content[0]=\"`$MASTER_PASSWORD = `\"$mp`\"\"}else{$content=\"`$MASTER_PASSWORD = `\"$mp`\"`r`n\"+$content};Set-Content \"$env:systemroot\UDCPCAdmin\validator.ps1\" $content -Force}else{Set-Content \"$env:systemroot\UDCPCAdmin\validator.ps1\" \"`$MASTER_PASSWORD = `\"$mp`\"\" -Force}"

powershell.exe -Command "$pcNum=$null; while(-not [int]::TryParse((Read-Host 'Ingrese el numero del PC (solo numeros)'), [ref]$pcNum)){Write-Host 'Error: Debe ser un numero' -ForegroundColor Red}; Set-Content -Path \"C:\Windows\windows_pc.cfg\" -Value \"PC_NUMBER=$pcNum\" -Force"

reg import C:\Windows\UDCPCAdmin\starter.reg

cls

echo UDC PC Admin 1.0.0 installed!
echo You're using version 1.0>C:\Windows\UDCPCAdmin\welcome.txt
pause