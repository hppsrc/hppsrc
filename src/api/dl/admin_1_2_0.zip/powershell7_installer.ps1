$ErrorActionPreference = "Stop"

if (-not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Write-Host "Este script debe ejecutarse como administrador." -ForegroundColor Red
    exit 1
}

$apiUrl = "https://api.github.com/repos/PowerShell/PowerShell/releases/latest"
$headers = @{ "User-Agent" = "PowerShellScript" }

Write-Host "Buscando la ultima version de PowerShell 7..."
$response = Invoke-RestMethod -Uri $apiUrl -Headers $headers
$latestVersion = $response.tag_name
$assets = $response.assets

$arch = if ([Environment]::Is64BitOperatingSystem) { "x64" } else { "x86" }

$installer = $assets | Where-Object { $_.name -match "win-${arch}.msi" }

if (-not $installer) {
    Write-Error "No se encontro un instalador MSI para la arquitectura '$arch'."
    exit 1
}

$downloadUrl = $installer.browser_download_url
$tempPath = "$env:TEMP\PowerShell-$latestVersion-$arch.msi"

Write-Host "Descargando PowerShell $latestVersion ($arch)..."
Invoke-WebRequest -Uri $downloadUrl -OutFile $tempPath

Write-Host "Lanzando el instalador con interfaz completa..."
Start-Process "msiexec.exe" -ArgumentList "/i `"$tempPath`"" -Wait

Write-Host "Instalacion finalizada o cancelada por el usuario."
