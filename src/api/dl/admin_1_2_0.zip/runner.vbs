' Script VBS para ejecutar PowerShell 7 de forma completamente invisible
' Este script no mostrará absolutamente ninguna ventana
' Guárdalo como "ejecutar_ps7_invisible.vbs"

' Crea un objeto Shell para ejecutar comandos
Set WshShell = CreateObject("WScript.Shell")

' Ejecuta PowerShell 7 (pwsh.exe) con tu script, completamente oculto (0 = invisible)
' La ruta está exactamente como la proporcionaste
WshShell.Run """C:\Program Files\PowerShell\7\pwsh.exe"" -WindowStyle Hidden -ExecutionPolicy Bypass -File ""C:\Windows\UDCPCAdmin\wrapper.ps1""", 0, False

' Libera el objeto Shell
Set WshShell = Nothing